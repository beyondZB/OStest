PUBLIC void* memcpy(void* p_dst, void* p_src, int size);
