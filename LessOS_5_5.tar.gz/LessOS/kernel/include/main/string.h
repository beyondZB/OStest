#ifndef	_STRING_H
#define _STRING_H
PUBLIC void* memcpy(void* p_dst, void* p_src, int size);

#endif	//_STRING_H
